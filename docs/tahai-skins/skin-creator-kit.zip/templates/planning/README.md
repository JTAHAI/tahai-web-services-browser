# Personal Planning

Select a horizon, set a priority, compare commitments in normal browser tabs, and check off a local follow-up. No calendar or task account is read.

This is editable source for a local operational skin. Review and change the manifest before signing or installing it. Its included preview image is shared starter artwork, not a screenshot of runtime behavior. Import, trust, activation, credential grants, and external actions remain separate decisions.
