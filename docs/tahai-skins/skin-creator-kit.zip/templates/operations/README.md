# Operations Console

Confirm scope, inspect authorized systems in live panes, validate the outcome, and prepare a separately reviewed handoff. The template starts no diagnostic or remote write.

This is editable source for a local operational skin. Review and change the manifest before signing or installing it. Its included preview image is shared starter artwork, not a screenshot of runtime behavior. Import, trust, activation, credential grants, and external actions remain separate decisions.
