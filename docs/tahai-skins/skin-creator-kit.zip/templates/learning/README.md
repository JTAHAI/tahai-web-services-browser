# Learning Space

Choose a lesson, practice in live browser tabs, optionally complete extra practice, and review progress locally. The workflow does not read a course account.

This is editable source for a local operational skin. Review and change the manifest before signing or installing it. Its included preview image is shared starter artwork, not a screenshot of runtime behavior. Import, trust, activation, credential grants, and external actions remain separate decisions.
