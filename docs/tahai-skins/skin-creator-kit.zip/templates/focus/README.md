# Blank Accessible Focus

Start from one browser pane, choose a task, and edit the local checklist. Keyboard access and browser recovery controls remain available.

This is editable source for a local operational skin. Review and change the manifest before signing or installing it. Its included preview image is shared starter artwork, not a screenshot of runtime behavior. Import, trust, activation, credential grants, and external actions remain separate decisions.
