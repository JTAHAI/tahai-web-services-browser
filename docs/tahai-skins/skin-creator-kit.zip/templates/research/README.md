# Research Desk

Enter a question, review independent sources in live browser panes, record uncertainty, then confirm the local brief. Selection capture and export require separate reviewed actions.

This is editable source for a local operational skin. Review and change the manifest before signing or installing it. Its included preview image is shared starter artwork, not a screenshot of runtime behavior. Import, trust, activation, credential grants, and external actions remain separate decisions.
