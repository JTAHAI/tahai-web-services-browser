# Creator Studio

Enter a brief, review assets and rights, work in a normal website or native editor, and confirm the result. Publishing remains a separate action on the chosen service.

This is editable source for a local operational skin. Review and change the manifest before signing or installing it. Its included preview image is shared starter artwork, not a screenshot of runtime behavior. Import, trust, activation, credential grants, and external actions remain separate decisions.
