# TAHAI Skin authoring reference

A TAHAI Skin changes the browser shell: the frame, toolbar, tabs, workspace
rail, and supported side-panel cards. It does not restyle websites, alter page
content, inject scripts, or change security indicators, permission prompts,
focus rings, or forced-colors behavior.

Start with `starter-skin` from the creator kit. The kit also includes an
offline visual editor (`studio.html`) and a deterministic builder
(`build_skin.py`). It targets Chromium 152.

## Fast path

1. Extract `skin-creator-kit.zip` to a writable folder.
2. Open `studio.html` for an offline color-only skin, or copy `starter-skin` to
   a new folder for custom artwork.
3. Give the skin a unique ID, name, creator, and license.
4. Check and build it with Python 3.9 or later:

   ```powershell
   py build_skin.py my-skin --check
   py build_skin.py my-skin my-skin-1.0.tahaiskin
   ```

5. In TAHAI, open **Skin packages**, select **Review local file**, choose the
   package, review it, then install and apply it.

The builder never edits the source folder and refuses to overwrite an existing
package. The browser performs a second, sandboxed validation at import time.

## Package layout

`.tahaiskin` is a ZIP archive containing files only. It has one top-level
manifest and one or more declared image assets:

```text
manifest.json
assets/preview.png
assets/rail-decoration.webp   # optional
```

Use `build_skin.py`; generic ZIP tools commonly add directory entries that
TAHAI rejects. The builder recalculates asset SHA-256 values and writes a
reproducible archive with only declared entries.

## Manifest contract

`manifest.json` permits exactly these top-level fields:

```json
{
  "schema_version": 1,
  "id": "my-skin",
  "name": "My Skin",
  "creator": "Example Studio",
  "license": "CC-BY-4.0",
  "compatibility": {
    "min_chromium_major": 152,
    "max_chromium_major": 152
  },
  "appearance": {
    "density": "comfortable",
    "reduced_motion": false,
    "light_tokens": {},
    "dark_tokens": {},
    "high_contrast_tokens": {}
  },
  "assets": []
}
```

Use a lowercase ID of 3–64 characters: letters, digits, and interior hyphens.
Keep the ID unchanged when publishing an update. `name`, `creator`, and
`license` are required, plain ASCII metadata of 1–128 characters. Do not use
quotes, backslashes, angle brackets, markup, or control characters.

Set the compatibility range to every Chromium major version you actually test.
The shipped starter is intentionally scoped to 152 so an untested package is
not silently accepted by a newer browser.

## Colors and accessibility

Each of `light_tokens`, `dark_tokens`, and `high_contrast_tokens` must contain
all ten lowercase `#rrggbb` colors:

```text
shell_background       toolbar_background   toolbar_foreground
tab_background         tab_foreground       rail_background
rail_foreground        accent               panel_background
panel_foreground
```

`density` is either `comfortable` or `compact`; `reduced_motion` is a boolean.
The toolbar, tab, rail, and panel foreground/background pairs must each meet a
4.5:1 contrast ratio. The Studio reports contrast while you edit, and the
builder and browser reject insufficient contrast.

## Artwork rules

Declare one to sixteen image files in `assets`. Every asset has exactly
`path`, `sha256`, and `purpose`; the builder fills the hash.

```json
{
  "path": "assets/preview.png",
  "sha256": "filled-by-build-skin",
  "purpose": "preview"
}
```

- Paths start with `assets/`, use lowercase letters, digits, `.`, `_`, `-`, and
  `/`, and end in `.png` or `.webp`.
- Paths cannot include `..`, backslashes, percent escapes, colons, empty
  segments, trailing dots, Windows device names, or duplicate names.
- Include exactly one `preview`; optional additional images use
  `shell-decoration`.
- Images are still PNG or WebP, each no larger than 4 MiB and 2048 × 2048.
- Total encoded assets are at most 8 MiB; the complete archive is at most
  9 MiB. The browser also limits decompression to 100:1 and decoded imagery to
  32 MiB total.

Shell decoration is displayed in a separate, noninteractive rail slot. Never
design it as a background for text or controls. Animated formats, SVG, HTML,
CSS, JavaScript, URLs, undeclared members, symbolic links, encrypted ZIPs, and
active content are rejected.

## Review and lifecycle

Review shows the package metadata and artwork before installation. **Try for
30 seconds** previews it without persisting settings; **Revert** restores the
saved appearance. Install updates retain one prior revision. Review that
revision to restore it, or use **Reset browser appearance** to return to the
native default. **Export reviewed skin** writes the exact reviewed archive.

Skins are profile-local. Private windows cannot install one, and managed policy
can disable skins or package installation. OS forced colors always take
precedence.

## Troubleshooting

- Run `py build_skin.py my-skin --check` first; it reports field, contrast,
  path, archive, and PNG errors.
- Confirm the package’s compatibility range includes the Chromium major at
  `chrome://version`.
- Rebuild after every asset edit so hashes update.
- If browser import fails after a successful local check, inspect image
  encoding, image dimensions, ZIP encryption, and unsupported WebP animation.
  A rejected import never replaces the installed revision.
